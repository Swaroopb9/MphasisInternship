package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
    features = "src/test/resources/features", // Path to your feature files
    glue = "stepdef",       // Package containing step definitions
    plugin = {
        "pretty",                            // Prints Gherkin steps in the console in a readable format
        "html:target/cucumber-reports.html", // Generates HTML report of test execution
        "json:target/cucumber-reports.json",  // Generates JSON report for additional integrations
        
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
		

    }
   // monochrome = true                    // Makes the console output readable by removing unnecessary characters
   // tags = "@SmokeTest"                     // Executes scenarios marked with this tag (optional, remove if not used)
)
public class TestRunner extends AbstractTestNGCucumberTests {
    // No additional code needed unless specific TestNG setups are required
}