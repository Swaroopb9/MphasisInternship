package stepdef;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.time.Duration;

import org.apache.maven.surefire.shared.io.FileUtils;
//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class stepdef {
    WebDriver driver;
    Actions actions;
    WebDriverWait wait;
    ExtentReports extent;
    ExtentTest test;

    @BeforeClass
    public void setupReport() {
    	ExtentSparkReporter sparkReporter = new ExtentSparkReporter("extentReport.html");
    	extent = new ExtentReports();
    	extent.attachReporter(sparkReporter);
        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);

        test = extent.createTest("E-Commerce Test");
        System.setProperty("webdriver.edge.driver", "msedgedriver.exe");
        driver = new EdgeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @Given("I navigate to {string}")
    public void navigateToUrl(String url) {
        test.info("Navigating to: " + url);
        driver.get(url);
        takeScreenshot("HomePage");
    }

    @When("I click on the {string} option")
    public void clickOption(String option) {
        test.info("Clicking on option: " + option);
        WebElement appliancesOption = driver.findElement(By.linkText(option));
        appliancesOption.click();
        takeScreenshot("ClickedOption");
    }

    @And("I hover over {string}")
    public void hoverOverOption(String option) {
        test.info("Hovering over: " + option);
        actions = new Actions(driver);
        WebElement tvAndAppliances = driver.findElement(By.xpath("//span[text()='" + option + "']"));
        actions.moveToElement(tvAndAppliances).perform();
        takeScreenshot("HoveredOption");
    }

    @Then("I select the {string} option")
    public void selectOption(String option) throws InterruptedException {
        test.info("Selecting option: " + option);
        WebElement hiddenElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//a[contains(text(),'" + option + "')]")));
        hiddenElement.click();
        takeScreenshot("SelectedOption");
    }

    @Then("I navigate to the fourth page in pagination")
    public void navigateToPage() {
        test.info("Navigating to page 4 in pagination");
        WebElement pagination = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//a[text()='4']")));
        pagination.click();
        takeScreenshot("FourthPage");
    }

    @When("I select the fifth product")
    public void selectProduct() throws InterruptedException {
        test.info("Selecting the fifth product");
        Thread.sleep(3000);
        WebElement productElement = driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div[6]/div/div/div/a/div[1]/div[1]/div/div/img"));
        productElement.click();
        takeScreenshot("SelectedProduct");
    }

    @Then("I switch to the new tab and verify the product details")
    public void switchToNewTab() {
        test.info("Switching to new tab to verify product details");
        String originalWindow = driver.getWindowHandle();
        Set<String> windowHandles = driver.getWindowHandles();
        for (String window : windowHandles) {
            if (!window.equals(originalWindow)) {
                driver.switchTo().window(window);
                break;
            }
        }
        String productDetails = driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//span[@class='VU-ZEz']")).getText();
        test.info("Product Details: " + productDetails);
        takeScreenshot("ProductDetails");
    }

    @And("I enter the PIN code for delivery")
    public void enterPincode() throws InterruptedException {
        test.info("Entering PIN code for delivery");
        WebElement pincodeInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='Ir+XS5 OG551k H1broz']//input")));
        pincodeInput.sendKeys("515671");
        driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//span[@class='i40dM4']")).click();
        Thread.sleep(3000);
        takeScreenshot("EnteredPincode");
    }

    @Then("I check if {string} and {string} buttons are displayed")
    public void checkButtons(String addToCart, String buyNow) throws InterruptedException {
        test.info("Checking if buttons " + addToCart + " and " + buyNow + " are displayed");
        Thread.sleep(3000);
        WebElement addToCartButton = driver.findElement(By.xpath("//li[@class='col col-6-12 ']"));
        test.info("Add to Cart button enabled: " + addToCartButton.isDisplayed());

        WebElement buyNowButton = driver.findElement(By.xpath("//li[@class='col col-6-12 flex']"));
        test.info("Buy Now button enabled: " + buyNowButton.isDisplayed());
        takeScreenshot("ButtonCheck");
    }

    public void takeScreenshot(String screenshotName) {
        File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(srcFile, new File("./Screenshots/" + screenshotName + ".png"));
            test.addScreenCaptureFromPath("./Screenshots/" + screenshotName + ".png");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @AfterClass
    public void tearDown() {
        test.info("Closing browser and flushing report");
        driver.quit();
        extent.flush();
    }
}