package stepdef;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

import java.time.Duration;

import io.cucumber.java.After;
//import ch.qos.logback.core.util.Duration;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepdef {
	 WebDriver driver;
	 Actions actions;
	 WebDriverWait wait;



	
	@Given("I navigate to {string}")
    public void navigateToUrl(String url) {
        System.setProperty("webdriver.edge.driver", "msedgedriver.exe");
        driver = new EdgeDriver();
        driver.get(url);
         wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
	
	 @When("I click on the {string} option")
	    public void clickOption(String option) {
	        WebElement appliancesOption = driver.findElement(By.linkText(option));
	        appliancesOption.click();
	    }
	 @And("I hover over {string}")
	    public void hoverOverOption(String option) {
	        actions = new Actions(driver);
	        WebElement tvAndAppliances = driver.findElement(By.xpath("//span[text()='" + option + "']"));
	        actions.moveToElement(tvAndAppliances).perform();
	    }
	 @Then("I select the {string} option")
	    public void selectOption(String option) throws InterruptedException {
		  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		// Thread.sleep(1000);
	        WebElement hiddenElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//a[contains(text(),'" + option + "')]")));
	        hiddenElement.click();
	    }

	    @Then("I navigate to the fourth page in pagination")
	    public void navigateToPage() {
	        WebElement pagination = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//a[text()='4']")));
	        pagination.click();
	    }
	    @When("I select the fifth product")
	    public void selectProduct() throws InterruptedException {
	    	Thread.sleep(3000);
	        WebElement productElement = driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div[6]/div/div/div/a/div[1]/div[1]/div/div/img")); // Update XPath for fifth product
	        productElement.click();
	    }
	    @Then("I switch to the new tab and verify the product details")
	    public void switchToNewTab() {
	        String originalWindow = driver.getWindowHandle();
	        Set<String> windowHandles = driver.getWindowHandles();
	        for (String window : windowHandles) {
	            if (!window.equals(originalWindow)) {
	                driver.switchTo().window(window);
	                break;
	            }
	        }
	        String productDetails = driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//span[@class='VU-ZEz']")).getText();
	        System.out.println("Product Details: " + productDetails);
	    }
	    @And("I enter the PIN code for delivery")
	    public void enterPincode() throws InterruptedException {
	    	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	         By inputLocator = By.xpath("//div[@class='Ir+XS5 OG551k H1broz']//input");

	        // try {
	             WebElement pincodeInput = wait.until(ExpectedConditions.elementToBeClickable(inputLocator));
	             
	             // Enter the PIN code dynamically
	            // String pinCode = "515671"; // You can fetch this dynamically from a config or user input
	             pincodeInput.sendKeys("515671");
	             
	             System.out.println("PIN Code entered successfully!");
	        // } catch (Exception e) {
	          //   System.out.println("Element not found: " + e.getMessage());

	        driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//span[@class='i40dM4']")).click();
	        Thread.sleep(1000);
	        String ss=driver.findElement(By.xpath("//div[@class='dYhUKY'][1]")).getText();
	        System.out.println(ss);
	         }

	    

	    @Then("I check if {string} and {string} buttons are displayed")
	    public void checkButtons(String addToCart, String buyNow) throws InterruptedException {
	    	Thread.sleep(3000);
	        WebElement addToCartButton = driver.findElement(By.xpath("//li[@class='col col-6-12 ']"));
	 
	        System.out.println("Add to Cart button enabled: " + (addToCartButton.isDisplayed() && addToCartButton.isEnabled()));
	        
	        WebElement buyNowButton = driver.findElement(By.xpath("//li[@class='col col-6-12 flex']"));
	        System.out.println("Buy Now button enabled: " + (buyNowButton.isDisplayed() && buyNowButton.isEnabled()));
	    }
	    
	    
	  // @After
	    //public void quit() {
	    	//driver.quit();
	    //}











}
