package POST;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class POST_CREATE_CURRENCY_WITH_INVALID_DETAILS {

    @Test
    public void validate_error_for_invalid_currency_details() {
        String apiUrl = "https://softwium.com/api/currencies";
        JSONObject invalidCurrencyDetails = new JSONObject();
        invalidCurrencyDetails.put("id", 182); // Valid ID
        invalidCurrencyDetails.put("code", "1234"); // Invalid code (exceeds 3 characters and numeric)
        invalidCurrencyDetails.put("name", ""); // Invalid name (empty value)

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            // Prepare POST request
            HttpPost request = new HttpPost(apiUrl);
            request.setEntity(new StringEntity(invalidCurrencyDetails.toString()));
            request.setHeader("Content-Type", "application/json");

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                JSONObject jsonResponse = new JSONObject(responseBody);

                // Assert error response for invalid details
                Assert.assertNotEquals(statusCode, 201, "Status code should not be 201 for invalid details.");
                Assert.assertTrue(jsonResponse.has("error"), "Response should contain an error message.");
                Assert.assertTrue(jsonResponse.get("error").toString().contains("Invalid details"),
                    "Error message should indicate invalid currency details.");

                System.out.println("Error for invalid currency details: " + jsonResponse.toString());
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Validation for invalid currency details failed: " + e.getMessage());
        }
    }
}
