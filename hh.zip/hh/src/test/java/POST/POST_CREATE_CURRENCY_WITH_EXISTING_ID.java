package POST;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class POST_CREATE_CURRENCY_WITH_EXISTING_ID {

    @Test
    public void validate_error_for_duplicate_currency_id() {
        String apiUrl = "https://softwium.com/api/currencies";
        JSONObject currencyDetailsWithDuplicateId = new JSONObject();
        currencyDetailsWithDuplicateId.put("id", 1); // Existing ID
        currencyDetailsWithDuplicateId.put("code", "ABC");
        currencyDetailsWithDuplicateId.put("name", "Arab country");

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            // Prepare POST request
            HttpPost request = new HttpPost(apiUrl);
            request.setEntity(new StringEntity(currencyDetailsWithDuplicateId.toString()));
            request.setHeader("Content-Type", "application/json");

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                JSONObject jsonResponse = new JSONObject(responseBody);

                // Assert error response for duplicate ID
                Assert.assertNotEquals(statusCode, 201, "Status code should not be 201 for duplicate ID.");
                Assert.assertTrue(jsonResponse.has("error"), "Response should contain an error message.");
                Assert.assertTrue(jsonResponse.get("error").toString().contains("Duplicate ID"),
                    "Error message should mention duplicate ID.");

                System.out.println("Error for duplicate currency ID: " + jsonResponse.toString());
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Validation for duplicate currency ID failed: " + e.getMessage());
        }
    }
}
