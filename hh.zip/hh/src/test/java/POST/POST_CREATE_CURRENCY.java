package POST;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class POST_CREATE_CURRENCY {

    @Test
    public void validate_create_currency_endpoint() {
        String apiUrl = "https://softwium.com/api/currencies";
        JSONObject newCurrencyDetails = new JSONObject();
        newCurrencyDetails.put("id", 171);
        newCurrencyDetails.put("code", "JPY");
        newCurrencyDetails.put("name", "Japan Currency");

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            // Prepare POST request
            HttpPost request = new HttpPost(apiUrl);
            request.setEntity(new StringEntity(newCurrencyDetails.toString()));
            request.setHeader("Content-Type", "application/json");

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                JSONObject jsonResponse = new JSONObject(responseBody);

                // Assert successful creation
                Assert.assertEquals(statusCode, 201, "Expected status code 201 for successful creation.");
                Assert.assertEquals(jsonResponse.get("id"), newCurrencyDetails.get("id"));
                Assert.assertEquals(jsonResponse.get("code"), newCurrencyDetails.get("code"));
                Assert.assertEquals(jsonResponse.get("name"), newCurrencyDetails.get("name"));

                System.out.println("New currency created successfully with valid details.");
                System.out.println("Response: " + jsonResponse.toString());
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("POST request validation for creating a new currency failed: " + e.getMessage());
        }
    }
}
