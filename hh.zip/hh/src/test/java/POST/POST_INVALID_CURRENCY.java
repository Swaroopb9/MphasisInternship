package POST;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class POST_INVALID_CURRENCY {

    @Test
    public void validate_invalid_currency_data() {

        String apiUrl = "https://softwium.com/api/currencies";

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpPost request = new HttpPost(apiUrl);
            request.setHeader("Content-Type", "application/json");

            // Invalid payload
            JSONObject payload = new JSONObject();
            payload.put("id", "A");  // Non-numeric ID
            payload.put("code", 123); // Should be a string
            payload.put("name", 76384); // Should be a string

            request.setEntity(new StringEntity(payload.toString()));

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());

                // Expecting a 400 Bad Request or similar error code
                Assert.assertTrue(statusCode >= 400, "API should reject invalid data");

                // Validate error message
                JSONObject jsonResponse = new JSONObject(responseBody);
                Assert.assertTrue(jsonResponse.has("error"), "Response should contain an error message");
                System.out.println("API correctly rejected invalid data.");

            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("POST request validation for currencies endpoint failed: " + e.getMessage());
        }
    }
}
