package POST;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CREATE_AND_GET_CURRENCY {

    @Test
    public void verifyNewCurrencyInGetPayload() {

        String baseApiUrl = "https://softwium.com/api";
        String createCurrencyEndpoint = "/currencies";
        String getCurrenciesEndpoint = "/currencies";

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            // Step 1: Create a new currency via POST request with the provided details
            JSONObject newCurrency = new JSONObject();
            newCurrency.put("id", 171);
            newCurrency.put("code", "JPY");
            newCurrency.put("name", "Japan Currency");

            HttpPost postRequest = new HttpPost(baseApiUrl + createCurrencyEndpoint);
            postRequest.setEntity(new StringEntity(newCurrency.toString(), "UTF-8"));
            postRequest.setHeader("Content-Type", "application/json");

            try (CloseableHttpResponse postResponse = httpClient.execute(postRequest)) {
                int postStatusCode = postResponse.getStatusLine().getStatusCode();
                String postResponseBody = EntityUtils.toString(postResponse.getEntity());
                JSONObject postResponseJson = new JSONObject(postResponseBody);

                Assert.assertEquals(postStatusCode, 201, "Currency creation failed!");
                System.out.println("New currency created successfully: " + postResponseJson.toString());
            }

            // Step 2: Validate the currency appears in the GET response payload
            HttpGet getRequest = new HttpGet(baseApiUrl + getCurrenciesEndpoint);

            try (CloseableHttpResponse getResponse = httpClient.execute(getRequest)) {
                int getStatusCode = getResponse.getStatusLine().getStatusCode();
                String getResponseBody = EntityUtils.toString(getResponse.getEntity());
                JSONArray jsonResponse = new JSONArray(getResponseBody);

                Assert.assertEquals(getStatusCode, 200, "Failed to fetch currencies!");
                boolean newCurrencyExists = false;

                for (int i = 0; i < jsonResponse.length(); i++) {
                    JSONObject obj = jsonResponse.getJSONObject(i);
                    if (obj.getInt("id") == 171 &&
                        obj.getString("code").equals("JPY") &&
                        obj.getString("name").equals("Japan Currency")) {
                        newCurrencyExists = true;
                        break;
                    }
                }

                Assert.assertTrue(newCurrencyExists, "Newly created currency does not appear in the GET payload!");
                System.out.println("Verified that the newly created currency appears in the GET payload.");

            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Test case execution failed: " + e.getMessage());
        }
    }
}
