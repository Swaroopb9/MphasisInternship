package POST;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class POST_EMPTY_PAYLOAD {

    @Test
    public void validate_empty_payload_rejection() {

        String apiUrl = "https://softwium.com/api/currencies";

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpPost request = new HttpPost(apiUrl);
            request.setHeader("Content-Type", "application/json");

            // No payload added to request

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());

                // Expecting a 400 Bad Request or similar error code
                Assert.assertTrue(statusCode >= 400, "API should reject empty payload");

                // Validate error message
                JSONObject jsonResponse = new JSONObject(responseBody);
                Assert.assertTrue(jsonResponse.has("error"), "Response should contain an error message");

                System.out.println("API correctly rejected empty payload.");

            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("POST request validation for empty payload failed: " + e.getMessage());
        }
    }
}
