package GET;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GET_SINGLE_CURRENCY {

    @Test
    public void validate_single_currency_endpoint() {

        String apiUrl = "https://softwium.com/api/currencies/{id}"; // Endpoint for single currency retrieval
        String currencyId = "89"; // Replace {id} with the valid currency ID (here it's set to 8)

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpGet request = new HttpGet(apiUrl.replace("{id}", currencyId)); // Dynamically update URL with currency ID

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                JSONObject jsonResponse = new JSONObject(responseBody);

                // Validate HTTP status code
                Assert.assertEquals(statusCode, 200);

                // Validate the response structure and data
                Assert.assertEquals(jsonResponse.get("id").toString(), currencyId, "Currency ID mismatch");
                Assert.assertTrue(jsonResponse.get("code") instanceof String, "Currency code is missing or invalid");
                Assert.assertTrue(jsonResponse.get("name") instanceof String, "Currency name is missing or invalid");

                System.out.println("Validated single currency record successfully.");

            }

        } catch (Exception e) {

            e.printStackTrace();
            Assert.fail("GET request validation for single currency endpoint failed: " + e.getMessage());

        }
    }
}
