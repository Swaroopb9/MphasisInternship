package GET;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GET_ALL_CURRENCIES {

    @Test
    public void validate_currencies_endpoint() {

        String apiUrl = "https://softwium.com/api/currencies";

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpGet request = new HttpGet(apiUrl);

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                JSONArray jsonResponse = new JSONArray(responseBody);

                Assert.assertEquals(statusCode, 200);

                // Validate that the response contains the correct data structure
                for (int i = 0; i < jsonResponse.length(); i++) {
                    JSONObject obj = jsonResponse.getJSONObject(i);
                    Assert.assertTrue(obj.get("id") instanceof Integer);
                    Assert.assertTrue(obj.get("code") instanceof String);
                    Assert.assertTrue(obj.get("name") instanceof String);
                }

                System.out.println("Validated all currency records with correct data types.");

            }

        } catch (Exception e) {

            e.printStackTrace();
            Assert.fail("GET request validation for currencies endpoint failed: " + e.getMessage());

        }
    }
}