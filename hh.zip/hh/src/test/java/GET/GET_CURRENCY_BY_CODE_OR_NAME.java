package GET;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GET_CURRENCY_BY_CODE_OR_NAME {

    @Test
    public void validate_api_does_not_support_get_by_code_or_name() {
        String apiUrlByCode = "https://softwium.com/api/currencies?code=AED";
        String apiUrlByName = "https://softwium.com/api/currencies?name=United Arab Emirates Dirham";

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            // Test GET request by code
            HttpGet requestByCode = new HttpGet(apiUrlByCode);
            try (CloseableHttpResponse responseByCode = httpClient.execute(requestByCode)) {
                int statusCodeByCode = responseByCode.getStatusLine().getStatusCode();
                String responseBodyByCode = EntityUtils.toString(responseByCode.getEntity());

                // Assert that GET by code is not supported
                Assert.assertNotEquals(statusCodeByCode, 200, "GET by code should not be supported.");
                System.out.println("Response for GET by code: " + responseBodyByCode);
            }

            // Test GET request by name
            HttpGet requestByName = new HttpGet(apiUrlByName);
            try (CloseableHttpResponse responseByName = httpClient.execute(requestByName)) {
                int statusCodeByName = responseByName.getStatusLine().getStatusCode();
                String responseBodyByName = EntityUtils.toString(responseByName.getEntity());

                // Assert that GET by name is not supported
                Assert.assertNotEquals(statusCodeByName, 200, "GET by name should not be supported.");
                System.out.println("Response for GET by name: " + responseBodyByName);
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Validation for unsupported GET requests by code or name failed: " + e.getMessage());
        }
    }
}
