package GET;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GET_Currencies_Structure_Validation {

    @Test
    public void validate_currencies_response_structure() {

        String apiUrl = "https://softwium.com/api/currencies"; // Replace with actual endpoint if necessary

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpGet request = new HttpGet(apiUrl);

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                JSONArray jsonResponse = new JSONArray(responseBody);

                // Verify the status code
                Assert.assertEquals(statusCode, 200, "Unexpected status code.");

                // Validate the structure, hierarchy, and data types of each currency object
                for (int i = 0; i < jsonResponse.length(); i++) {
                    JSONObject obj = jsonResponse.getJSONObject(i);

                    // Verify the presence of expected fields
                    Assert.assertTrue(obj.has("id"), "Missing 'id' field.");
                    Assert.assertTrue(obj.has("code"), "Missing 'code' field.");
                    Assert.assertTrue(obj.has("name"), "Missing 'name' field.");

                    // Verify data types of fields
                    Assert.assertTrue(obj.get("id") instanceof Integer, "'id' is not a String.");
                    Assert.assertTrue(obj.get("code") instanceof String, "'name' is a String.");
                    Assert.assertTrue(obj.get("name") instanceof String, "'symbol' is a String.");
                }

                System.out.println("Validated the hierarchy, structure, and data types for all currency records.");

            }

        } catch (Exception e) {

            e.printStackTrace();
            Assert.fail("GET request validation for currencies endpoint failed: " + e.getMessage());

        }
    }
}
