package PUT;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PUT_EMPTY_BODY {

    @Test
    public void validate_empty_body_rejection() {

        String apiUrl = "https://softwium.com/api/currencies/1"; // Assuming ID is part of the URL

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpPut request = new HttpPut(apiUrl);
            request.setHeader("Content-Type", "application/json");

            // No payload added to request (empty body)

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());

                // Expecting a 400 Bad Request or similar error code
                Assert.assertTrue(statusCode >= 400, "API should reject empty request body");

                // Validate error message
                JSONObject jsonResponse = new JSONObject(responseBody);
                Assert.assertTrue(jsonResponse.has("error"), "Response should contain an error message");

                System.out.println("API correctly rejected empty request body.");

            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("PUT request validation for empty body failed: " + e.getMessage());
        }
    }
}
