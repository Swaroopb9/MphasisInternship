package PUT;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PUT_GET_VERIFICATION {

    @Test
    public void validate_update_reflected_in_get() {

        String apiUrlPut = "https://softwium.com/api/currencies/1"; // Assuming ID is part of the URL
        String apiUrlGet = "https://softwium.com/api/currencies/1"; // Endpoint to fetch updated details

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            // Step 1: Send PUT request to update the currency
            HttpPut putRequest = new HttpPut(apiUrlPut);
            putRequest.setHeader("Content-Type", "application/json");

            JSONObject payload = new JSONObject();
            payload.put("id", 1);
            payload.put("code", "IND");
            payload.put("name", "New IND Currency");

            putRequest.setEntity(new StringEntity(payload.toString()));

            try (CloseableHttpResponse putResponse = httpClient.execute(putRequest)) {

                int putStatusCode = putResponse.getStatusLine().getStatusCode();
                Assert.assertEquals(putStatusCode, 200, "API should successfully update the currency");

                System.out.println("PUT request successfully updated the currency.");
            }

            // Step 2: Send GET request to verify changes
            HttpGet getRequest = new HttpGet(apiUrlGet);

            try (CloseableHttpResponse getResponse = httpClient.execute(getRequest)) {

                int getStatusCode = getResponse.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(getResponse.getEntity());

                Assert.assertEquals(getStatusCode, 200, "API should successfully fetch the updated currency");

                // Validate updated details
                JSONObject jsonResponse = new JSONObject(responseBody);
                Assert.assertEquals(jsonResponse.getInt("id"), 1, "ID should match the requested update");
                Assert.assertEquals(jsonResponse.getString("code"), "IND", "Code should be updated");
                Assert.assertEquals(jsonResponse.getString("name"), "New IND Currency", "Name should be updated");

                System.out.println("GET request verified the updated currency data successfully.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Validation for PUT-GET reflection failed: " + e.getMessage());
        }
    }
}
