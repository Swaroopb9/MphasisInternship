package PUT;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class UPDATE_CURRENCY_INVALID_ID {

    @Test
    public void verify_currency_update_with_invalid_id_fails() {
        String apiUrl = "https://softwium.com/api/currencies/0"; // Using ID 0 as the non-existent ID
        JSONObject requestBody = new JSONObject();
        requestBody.put("id", 0);
        requestBody.put("code", "IND");
        requestBody.put("name", "New IND Currency");

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpPut request = new HttpPut(apiUrl);
            request.setEntity(new StringEntity(requestBody.toString(), "UTF-8"));
            request.setHeader("Content-Type", "application/json");

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());

                // Assert that the status code indicates failure (e.g., 404 or 400)
                Assert.assertNotEquals(statusCode, 200, "API should not return 200 for a non-existent ID update!");
                Assert.assertTrue(
                    statusCode == 400 || statusCode == 404,
                    "Expected status code 400 or 404, but got: " + statusCode
                );

                // Optionally, validate the error message in the response
                JSONObject jsonResponse = new JSONObject(responseBody);
                Assert.assertTrue(
                    jsonResponse.has("error"),
                    "Response body does not contain 'error' key!"
                );

                System.out.println("Currency update validation with non-existent ID failed as expected. Status Code: " + statusCode);

            }
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Currency update validation with non-existent ID failed due to exception: " + e.getMessage());
        }
    }
}
