package PUT;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PUT_UPDATE_CURRENCY {

    @Test
    public void validate_currency_update_success() {

        String apiUrl = "https://softwium.com/api/currencies/1"; // Assuming ID is part of the URL

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpPut request = new HttpPut(apiUrl);
            request.setHeader("Content-Type", "application/json");

            // Valid payload for updating a currency
            JSONObject payload = new JSONObject();
            payload.put("id", 1);
            payload.put("code", "IND");
            payload.put("name", "New IND Currency");

            request.setEntity(new StringEntity(payload.toString()));

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());

                // Expecting a 200 OK or similar success response
                Assert.assertEquals(statusCode, 200, "API should successfully update the currency");

                // Validate response contains updated details
                JSONObject jsonResponse = new JSONObject(responseBody);
                Assert.assertEquals(jsonResponse.getInt("id"), 1, "ID should match the requested update");
                Assert.assertEquals(jsonResponse.getString("code"), "IND", "Code should be updated");
                Assert.assertEquals(jsonResponse.getString("name"), "New IND Currency", "Name should be updated");

                System.out.println("API successfully updated the currency.");

            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("PUT request validation for updating currency failed: " + e.getMessage());
        }
    }
}
