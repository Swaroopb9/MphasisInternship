package DELETE;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.json.JSONObject;

public class DELETE_NON_EXISTENT_CURRENCY {

    @Test
    public void verify_deletion_of_non_existent_currency() {

        String apiUrl = "https://softwium.com/api/currencies";
        String nonExistentId = "999999"; // Ensure this ID doesn't exist

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            HttpDelete request = new HttpDelete(apiUrl + "/" + nonExistentId);

            try (CloseableHttpResponse response = httpClient.execute(request)) {

                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                JSONObject jsonResponse = new JSONObject(responseBody);

                // Expecting a failure response (404 or other relevant error code)
                Assert.assertNotEquals(statusCode, 200, "API should NOT return success for non-existent ID.");
               // Assert.assertTrue(jsonResponse.has("error"), "Response should contain an error message.");
                
                System.out.println("Verified that API does not delete a non-existent currency successfully.");

            }

        } catch (Exception e) {

            e.printStackTrace();
            Assert.fail("DELETE request validation failed: " + e.getMessage());

        }
    }
}
