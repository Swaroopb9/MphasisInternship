package DELETE;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DELETE_CURRENCY_BY_ID {

    @Test
    public void validate_currency_deletion_endpoint() {
        String apiUrl = "https://softwium.com/api/currencies/"; // Base URL for the API
        int currencyIdToDelete = 123; // Replace with an existing currency ID for testing

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

            // Step 1: Send DELETE request to delete the currency
            HttpDelete deleteRequest = new HttpDelete(apiUrl + currencyIdToDelete);

            try (CloseableHttpResponse deleteResponse = httpClient.execute(deleteRequest)) {
                int deleteStatusCode = deleteResponse.getStatusLine().getStatusCode();
                Assert.assertEquals(deleteStatusCode, 200, "Currency deletion failed!");

                System.out.println("Currency with ID " + currencyIdToDelete + " successfully deleted.");
            }

            // Step 2: Verify that the currency no longer exists using a GET request
            HttpGet getRequest = new HttpGet(apiUrl + currencyIdToDelete);

            try (CloseableHttpResponse getResponse = httpClient.execute(getRequest)) {
                int getStatusCode = getResponse.getStatusLine().getStatusCode();
                Assert.assertEquals(getStatusCode, 200, "Deleted currency still exists!");

                String getResponseBody = EntityUtils.toString(getResponse.getEntity());
                System.out.println("Verification response: " + getResponseBody);
            }

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Currency deletion validation failed due to: " + e.getMessage());
        }
    }
}
