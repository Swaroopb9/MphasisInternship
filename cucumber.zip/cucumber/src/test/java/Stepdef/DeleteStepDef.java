package Stepdef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

public class DeleteStepDef {
	String endpoint;
    Response response;
    //deleting valid currency id
    @Given(" I use relaxed HTTPS validation")
    public void i_use_relaxed_https_validation() {
        RestAssured.useRelaxedHTTPSValidation();
    }

    @When("I send a DELETE request to {string}")
    public void i_send_a_delete_request_to(String endpoint) {
        response = given()
                    .contentType("application/json")
                    .when()
                    .delete("https://softwium.com/api/currencies/" + endpoint);
       System.out.println("sucessfully delete currency"+endpoint);
    }

    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(Integer statusCode) {
        assertEquals(response.getStatusCode(), statusCode, "Unexpected Status Code!");
       // System.out.println("sucessfully deleted currency"+endpoint);
    }
}