package Stepdef;
 
import io.cucumber.java.en.Then;

import io.cucumber.java.en.When;

import io.restassured.response.Response;
 
import static io.restassured.RestAssured.given;

import static org.testng.Assert.assertEquals;

public class delete_tcd_03_stepdef {

  int statuscode;
  Response response;
//deleting without giving the endpoint
	@When("I send a DELETE request to the  endpoint")

	public void i_send_a_delete_request_to_the_endpoint() {

		 response= given()
	        .when()
	          .delete("https://softwium.com/api/currencies")
	        .then()
	          .statusCode(405)
	          .extract().response();

	}
	@Then("I should get a {int} status code")
	public void i_should_get_a_status_code(Integer int1) {
		assertEquals(response.getStatusCode(),int1,"Status does not match");
		 System.out.println("Not giving any endpoint");
		 System.out.println("Verify 405 status code successfully!");

	}

}

 