package Stepdef;
 
import io.cucumber.java.en.Given;

import io.cucumber.java.en.Then;

import io.cucumber.java.en.When;

import io.restassured.RestAssured;
 
import static io.restassured.RestAssured.given;

public class delete_tcd_05_stepdef {
	
//Accessing a deleted currency
	
    @Given("I use relaxed HTTPS validation api")
    public void useRelaxedHttpsValidation() {

        RestAssured.useRelaxedHTTPSValidation();

    }
    @When("I send a delete request to the {string} endpoint")
    public void senddeleteRequest(String s) {
        given()
        .when()
            .delete("https://softwium.com/api/currencies/"+s);
           //  System.out.println("deleted currency" +s);

    }
 
 
    @When("I send a GET request to the {string} endpoint")
    public void sendGetRequest(String s) {
        given()
        .when()
            .get("https://softwium.com/api/currencies/"+s);
        System.out.println("deleted currency" +s);

    }
 
    @Then("I should receive a 404 status code from response")
    public void verifyStatusCode() {

        given()
        .when()
            .get("https://softwium.com/api/currencies/1")
        .then()
            .statusCode(404);

    }
 
   

    

}

 