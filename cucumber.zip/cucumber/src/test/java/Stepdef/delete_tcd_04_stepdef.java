package Stepdef;
 
import java.util.HashMap;
 
import io.cucumber.java.en.Given;

import io.cucumber.java.en.Then;

import io.cucumber.java.en.When;

import io.restassured.RestAssured;
 
import static io.restassured.RestAssured.given;

public class delete_tcd_04_stepdef {
//Create and delete a currency
	HashMap<String, String> requestBody;
    @Given("I use relaxed api HTTPS validation")
    public void useRelaxedHttpsValidation() {
        RestAssured.useRelaxedHTTPSValidation();

    }
 
    @Given("I set the request body with the currency code as {string} and name as {string}")
    public void setRequestBody(String code, String name) {

        requestBody = new HashMap<>();
        requestBody.put("code", code);
        requestBody.put("name", name);

    }
 
    @When("I send a POST request to the {string} endpoint")

    public void sendPostRequest(String  requestBody) {

        given()
            .body(requestBody)
        .when()
            .post("https://softwium.com/api/currencies")
        .then()
            .statusCode(201);

    }
 
    @When("I send a DELETE api request to the {string} endpoint")

    public void sendDeleteRequest(String s) {

        given()
        .when()
            .delete("https://softwium.com/api/currencies/"+s)
        .then()
           .statusCode(200);

    }
 
    @Then("I should receive a response {int} status code")

    public void verifyStatusCode(int statusCode) {

        // Assertions can be included here if required

        System.out.println("Verified " + statusCode + " status code successfully!");

    }

}

 