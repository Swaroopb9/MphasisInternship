package Stepdef; 

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.given; 

public class delete_tcd_02_stepdef { 

//deleting invalid currency id

@Given("I use relaxed HTTPS validation")
public void i_use_relaxed_https_validation() {
	RestAssured.useRelaxedHTTPSValidation();
}
@When("I send a DELETE request to the {string} endpoint")
public void i_send_a_delete_request_to_the_endpoint(String string) {
	given()
    .header("content-type", "application/json")
.when()
    .delete("https://softwium.com/api/currencies/"+ string)
.then()
    .statusCode(404);
	System.out.println("successfully deletes" +string);
}
@Then("I should receive a {int} status code")
public void i_should_receive_a_status_code(Integer int1) {
	
	System.out.println("Verified 404 status code successfully!");
	//System.out.println(int1);
}
}