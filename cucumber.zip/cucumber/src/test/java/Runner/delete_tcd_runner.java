package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;

import io.cucumber.testng.CucumberOptions;
 
 
@CucumberOptions(features = "src/test/resources/Feature",

                 glue = "Stepdef",
                 plugin = {"pretty", "html:target/cucumber-reports(delete).html"}

				// tags="@set8"

				)
 
 
public class delete_tcd_runner extends AbstractTestNGCucumberTests {
 
}

 