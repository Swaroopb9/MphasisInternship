package DELETE;




import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;

import java.util.HashMap;

public class Delete {
	
	//deleting valid currency id
	
	@Test(priority=1)
	void delete() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
		.when()
		    .delete("https://softwium.com/api/currencies/1")
		.then()
		    .statusCode(200)
		    .log().all();
		
	}
	
	//deleting invalid currency id
	
	@Test(priority=2)
	void delete1() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
		   .header("content-type","application/json")
		.when() 
		   .delete("https://softwium.com/api/currencies/1777")
		.then()
			.statusCode(404);
	}
	
	//deleting without giving end point
	
	@Test(priority=3)
	void delete2() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
		.when()
			.delete("https://softwium.com/api/currencies")
		.then()
			.statusCode(405);
	}
	
	//creating a new currency
	
	@Test(priority=4)
	void post() {
		RestAssured.useRelaxedHTTPSValidation();
		HashMap h1=new HashMap();
		h1.put("code", "rew");
		h1.put("name","receuggut");
		given()
			.body(h1)
		.when()
			.post("https://softwium.com/api/currencies")
		.then()
			.statusCode(201);
		
	}
	
	//deleting newly created currency
	
	@Test(priority=5,dependsOnMethods="post")
	void delete3() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
		.when()
			.delete("https://softwium.com/api/currencies/171")
		.then()
		     .statusCode(200);
	}
	
	//deleting already deleted currency
	
	@Test(priority=6,dependsOnMethods="delete")
	void delete4() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
		.when()
			.get("https://softwium.com/api/currencies/1")
		.then()
			.statusCode(404);
	}
 
}
