package Example;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class RestAssuredPostExample {
	SoftAssert sa =new SoftAssert();	
	
	@Test(priority=1)
   public void get() {
		RestAssured.useRelaxedHTTPSValidation();
	 given()
	   .header("content-type","application/json")
	 .when()
	     .get("https://softwium.com/api/currencies/1")
	     
	  .then()
	     .body("name",equalTo("United Arab Emirates Dirham"))
	     .log().body();
	  
	
	}
	
	/*
	@Test(priority=2)
	void post() {
		RestAssured.useRelaxedHTTPSValidation();
		HashMap hm = new HashMap();
		hm.put("code", "hgf");
		hm.put("name", "higtfe");
		given()
		  .header("content-type","application/json")
		  .body(hm)
		.when()
		  .post("https://softwium.com/api/currencies")
		.then()
		  .statusCode(201)
		  .log().all();
	}
	
	@Test(priority=3)
	void patch() {
		RestAssured.useRelaxedHTTPSValidation();
		HashMap h1 =new HashMap();
		h1.put("code","aaa");
		h1.put("name", "asdfgtrewq");
		given()
	    	.header("content-type","application/json")
	    	.body(h1)
		.when()
		   .patch("https://softwium.com/api/currencies/1")
		.then()
		   .statusCode(200)
		   .log().all();
	}
	
	@Test(priority=4)
	void put() {
		RestAssured.useRelaxedHTTPSValidation();
		HashMap h2=new HashMap();
		h2.put("id",1);
		h2.put("code", "bbb");
		h2.put("name", "asdfgtrewq");
		given()
			.header("content-type","application/json")
			.body(h2)
		.when()
		  .put("https://softwium.com/api/currencies/1")
		.then()
		   .statusCode(200)
		   .log().all();
		
	}
	
	@Test(priority=5)
	void delete() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
			.header("content-type","application/json")
		.when()
			.delete("https://softwium.com/api/currencies/1")
		.then()
			.statusCode(200)
			.log().all();
	}*/
	
	
}
