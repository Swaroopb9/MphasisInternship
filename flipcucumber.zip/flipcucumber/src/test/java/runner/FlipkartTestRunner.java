package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/resources/features",  // Path to feature files
        glue = "stepdef",             // Package containing step definitions
        plugin = {"pretty", "json:target/cucumber.json", "html:target/cucumber-reports.html"}, // Reports
        monochrome = true                          // Improved console output
)
public class FlipkartTestRunner extends AbstractTestNGCucumberTests {
}