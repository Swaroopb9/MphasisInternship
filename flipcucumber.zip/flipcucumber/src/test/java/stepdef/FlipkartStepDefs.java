package stepdef;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.*;

public class FlipkartStepDefs {
    WebDriver driver;
    WebDriverWait wait;
    String parentWindow;

    @Given("I open the Flipkart website")
    public void i_open_the_flipkart_website() {
        System.setProperty("webdriver.msedge.driver", "msedgedriver.exe");
        driver = new EdgeDriver();
        driver.get("https://www.flipkart.com");
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @When("I click on the {string} option")
    public void i_click_on_the_option(String option) {
        WebElement menuOption = driver.findElement(By.linkText(option));
        menuOption.click();
    }

    @When("I hover over {string}")

    public void i_hover_over(String option) {
        Actions actions = new Actions(driver);
        WebElement hoverElement = driver.findElement(By.xpath("//span[text()='" + option + "']"));
        actions.moveToElement(hoverElement).perform();
    }

    @When("I click on {string} under the menu")
    public void click_on_submenu(String submenu) {
        WebElement subMenuElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'" + submenu + "')]")));
        subMenuElement.click();
    }

    @When("I navigate to the 4th pagination page")
    public void i_navigate_to_the_4th_pagination_page() {

        WebElement pagination = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//nav[@class=\"WSL9JP\"]//a[text()='4']")));
        pagination.click();
    }

    @When("I select the 5th product from the list")
    public void i_select_the_5th_product_from_the_list() throws InterruptedException {
    	Thread.sleep(1000);
        WebElement product = driver.findElement(By.xpath("(//div[@class=\"cPHDOP col-12-12\"])[5]"));
        product.click();
    }

    @Then("I should switch to the new tab with product details")
    public void i_should_switch_to_the_new_tab_with_product_details() {
        parentWindow = driver.getWindowHandle();
        Set<String> allWindows = driver.getWindowHandles();

        for (String windowHandle : allWindows) {
            if (!windowHandle.equals(parentWindow)) {
                driver.switchTo().window(windowHandle);
                System.out.println("Switched to the new tab: " + driver.getTitle());
                break;
            }
        }
    }

    @Then("I should see the product name and price")
    public void i_should_see_the_product_name_and_price() {
        WebElement productName = driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//span[@class='VU-ZEz']"));
        WebElement productPrice = driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//div[@class='Nx9bqj CxhGGd']"));
        System.out.println("Product Name: " + productName.getText());
        System.out.println("Product Price: " + productPrice.getText());
    }

    @When("I enter the pincode {string} for delivery check")
    public void i_enter_the_pincode_for_delivery_check(String pincode) {
        driver.findElement(By.xpath("//input[@id=\"pincodeInputId\"]")).sendKeys(pincode);
        driver.findElement(By.xpath("//span[@class=\"i40dM4\"]")).click();
    }

    @Then("I verify if Delivery by is displayed")
    public void i_verify_if_is_displayed(String expectedMessage) throws InterruptedException {
    	Thread.sleep(1000);
        String actualMessage = driver.findElement(By.xpath("//div[@class='nRBH83'][1]")).getText();
        System.out.println("Message: " + actualMessage);
        if (actualMessage.contains(expectedMessage)) {
            check_buttons();
        } else {
            System.out.println("Condition false");
        }
    }

    @Then("I check if Add to Cart and Buy Now buttons are visible and enabled")
    public void check_buttons() throws InterruptedException {
    	Thread.sleep(1000);
        WebElement addToCartButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@class='col col-6-12 ']")));
        WebElement buyNowButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@class='col col-6-12 flex']")));
        System.out.println("Button options: " + (addToCartButton.isDisplayed() && addToCartButton.isEnabled()) + " " + (buyNowButton.isDisplayed() && buyNowButton.isEnabled()));
    }
}