package flipkart.flipkart;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import java.util.Set;
 
public class FlipkartAutomation {

    public static void main(String[] args) throws InterruptedException {

        // Set the path to the ChromeDriver executable

        System.setProperty("webdriver.edge.driver", "msedgedriver.exe");
 
        // Initialize the WebDriver

        WebDriver driver = new EdgeDriver();

        try {

            // Open the Flipkart website

            driver.get("https://www.flipkart.com");

            // Close the login pop-up (if it appears)

            try {

                WebElement closeLoginPopup = driver.findElement(By.xpath("//button[contains(text(),'✕')]"));

                closeLoginPopup.click();

            } catch (Exception e) {

                System.out.println("Login popup not displayed.");

            }
 
            // Click the "Appliances" option on the home page

            WebElement appliancesOption = driver.findElement(By.linkText("Appliances")); // Replace linkText if necessary

            appliancesOption.click();
 
            // Hover over "TV & Appliances"

            Actions actions = new Actions(driver);

            WebElement tvAndAppliances = driver.findElement(By.xpath("//span[text()='TVs & Appliances']")); // Replace locator if necessary

            actions.moveToElement(tvAndAppliances).perform();
 
            // Select the "Side-by-Side" option

           // WebElement sideBySideOption = driver.findElement(By.xpath("//a[contains(text(),'Side by Side')]")); // Replace locator if necessary
           // WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
            WebElement hiddenElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Side by Side')]")));
           // WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            //WebElement hiddenElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//your_xpath")));
            

            hiddenElement.click();
 
            // Select the fourth page in pagination

            WebElement pagination = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='4']")));

            pagination.click();

            Thread.sleep(3000); // Wait for the page to load

            // Select the fifth product
         //   Thread.sleep(2000);

            WebElement fifthProduct = driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div/div[2]/div[6]/div/div/div/a/div[1]/div[1]/div/div/img")); // Adjust locator as necessary

            fifthProduct.click();

            Thread.sleep(3000); // Wait for product details page to load
            
            
            String originalWindow = driver.getWindowHandle();

         // Wait for new tab and switch to it
            Set<String> windowHandles = driver.getWindowHandles();
            for (String window : windowHandles) {
                if (!window.equals(originalWindow)) {
                    driver.switchTo().window(window);
                    break;
                }
            }
         // Verify content in new tab
          //  WebElement productTitle = driver.findElement(By.cssSelector("your-product-title-selector"));
            //System.out.println("Product Title: " + productTitle.getText());
            
           String s= driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//span[@class='VU-ZEz']")).getText();
           System.out.println(s);
           
           Thread.sleep(1000);
           driver.findElement(By.xpath("//div[@class='Ir+XS5 H1broz']//input")).sendKeys("515671");
           driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//span[@class='i40dM4']")).click();
           
          String w= driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//div[@class='hVvnXm']")).getText();
          System.out.println(w);
          
         WebElement atc= driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//button[@class='QqFHMw vslbG+ In9uk2']")) ;
       Boolean t=  atc.isDisplayed() && atc.isEnabled();
       System.out.println(t);
       
       WebElement bn= driver.findElement(By.xpath("//div[@class='cPHDOP col-12-12']//button[@class='QqFHMw vslbG+ _3Yl67G _7Pd1Fp']")) ;
       Boolean t1=  bn.isDisplayed() && bn.isEnabled();
       System.out.println(t1);
           
          
          
           }
        catch(Exception e){
        	System.out.println(e);
        	   
           }
 


            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
               
            

          

    }
        
 

}
 